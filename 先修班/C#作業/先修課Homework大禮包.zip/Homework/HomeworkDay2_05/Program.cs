﻿using System;

namespace HomeworkDay2_05
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("請輸入數字（用 , 分隔）：");
            string input = Console.ReadLine();
            string[] strArray = input.Split(',');

            //int[] numArray = Array.ConvertAll(strArray, new Converter<string, int>(int.Parse));
            //int[] numArray = Array.ConvertAll(strArray, int.Parse);
            int[] numArray = Array.ConvertAll(strArray, s => int.Parse(s));
            Array.Sort(numArray);
            Array.Reverse(numArray);
            Console.WriteLine("排序結果");
            string result = string.Join(",", numArray);
            Console.WriteLine(result);

            Console.ReadLine();
        }
    }
}