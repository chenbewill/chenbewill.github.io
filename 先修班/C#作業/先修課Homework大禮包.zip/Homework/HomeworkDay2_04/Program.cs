﻿using System;

namespace HomeworkDay2_04
{
    internal class Program
    {
        public static void Main(string[] args)
        {

            Console.WriteLine("請輸入數字（用 , 分隔）：");
            string input = Console.ReadLine();
            string[] strArray = input.Split(',');
            int[] numArray = new int[strArray.Length];
            for (int i = 0; i < numArray.Length; i++)
            {
                numArray[i] = int.Parse(strArray[i]);
            }

            Array.Sort(numArray);

            Console.WriteLine("排序結果");
            foreach (int item in numArray)
            {
                Console.WriteLine(item);
            }

            Console.ReadLine();
        }
    }
}