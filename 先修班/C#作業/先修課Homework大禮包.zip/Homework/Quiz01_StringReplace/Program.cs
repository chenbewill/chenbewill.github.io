﻿using System;

namespace Quiz01_StringReplace
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            // 將1~100顯示在畫面上，但是，
            // 如果遇到2個倍數則顯示"螃蟹"，
            // 如果遇到3的倍數則顯示"章魚"，
            // 如果同時為2跟3的倍數則顯示"金槍魚"
            for (int i = 1; i < 101; i++)
            {

                if (i % 2 == 0 && i % 3 == 0)
                {
                    Console.WriteLine("金槍魚");
                }
                else if (i % 2 == 0)
                {
                    Console.WriteLine("螃蟹");
                }
                else if (i % 3 == 0)
                {
                    Console.WriteLine("章魚");
                }
                else
                {
                    Console.WriteLine(i);
                }
            }

            Console.ReadLine();
        }
    }
}