﻿using System;

namespace HomeworkDay3_04
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Role r1 = new Role();
            Role r2 = new Role();
            Console.WriteLine("攻擊前...");
            r1.ShowInfo();
            r2.ShowInfo();
            Console.WriteLine("攻擊後...");
            Battle(r1, r2);
            r1.ShowInfo();
            r2.ShowInfo();

            Console.ReadLine();
        }

        static void Battle(Role role1, Role role2)
        {
            role1.Attack(role2);
            role2.Attack(role1);
        }
    }

    public class Role
    {
        public Role()
        {
            Console.WriteLine("請輸入角色名稱：");
            Name = Console.ReadLine();
            Console.WriteLine("請輸入血量：");
            Hp = int.Parse(Console.ReadLine());
            Console.WriteLine("請輸入攻擊力：");
            AttackPoint = int.Parse(Console.ReadLine());
        }
        public string Name { get; set; }
        public int AttackPoint { get; set; }

        public int Hp { get; set; }

        public void ShowInfo()
        {
            Console.WriteLine($"{Name} 的血量：{Hp}，攻擊力：{AttackPoint}點");
        }

        public void Attack(Role enemy)
        {
            enemy.Hp = enemy.Hp - this.AttackPoint;
            if (enemy.Hp < 0)
            {
                enemy.Hp = 0;
            }
        }

    }
}