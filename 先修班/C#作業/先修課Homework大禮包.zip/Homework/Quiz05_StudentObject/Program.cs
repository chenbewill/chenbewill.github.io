﻿using System;
using System.Collections.Generic;

namespace Quiz05_StudentObject
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Course bs = new Course("BS", 10);
            bs.Name = "下課";
            

            Student dann = new Student
            {
                Number = "S11001",
                Name = "Dann",
                Courses = new Course[]
                {
                    new Course("微積分",4),
                    new Course("線性代數",3),
                    new Course("普通物理",3),
                    new Course("物理實驗",1),
                    bs
                }
            };
            
            dann.ShowInfo();
            Student bill = new Student
            {
                Number = "S11002",
                Name = "Bill",
                Courses = new Course[]
                {
                    new Course("視唱",3),
                    new Course("和弦",4),
                    new Course("BS",10),
                    bs

                }
            };
            
            bill.ShowInfo();

            Console.ReadLine();
        }
        
    }

    public class Student
    {
        public string Number { get; set; }
        public string Name { get; set; }
        public Course[] Courses { get; set; }

        public void ShowInfo()
        {
            Console.WriteLine($"學號：{Number}");
            Console.WriteLine($"姓名：{Name}");
            Console.WriteLine("選課");
            int totalCredit = 0;
            foreach (Course item in Courses)
            {
                Console.WriteLine($"\t{item.Name}，{item.Credit}");
                totalCredit += item.Credit;
            }

            Console.WriteLine($"總共：{totalCredit}學分");
            Console.WriteLine("--------");

        }

      
    }

    public class Course
    { 
        public Course(string name, int credit)
        {
            Name = name;
            Credit = credit;
        }
        public string Name { get; set; }
        public int Credit { get; set; }
    }
}