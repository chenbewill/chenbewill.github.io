﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //攝氏 = 5/9 乘 (華氏溫度 - 32)
            Console.WriteLine("請輸入整數的華氏溫度:");
            string input = Console.ReadLine();
            int tempF = int.Parse(input);
            double tempC = (double)5 / 9 * (tempF - 32);
            //10 / 3 => 3...1
            // 5 / 9 => 0...5
            Console.WriteLine("對應的攝氏溫度為:");
            Console.WriteLine(tempC);
            Console.ReadLine();
        }
    }
}
