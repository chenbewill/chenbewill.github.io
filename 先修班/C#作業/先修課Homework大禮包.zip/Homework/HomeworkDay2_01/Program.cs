﻿using System;

namespace HomeworkDay2_01
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            string input = Console.ReadLine();
            string[] words = input.Split(' ');
            Console.WriteLine($"{input} 一共有 {words.Length} 個單字");
            Console.ReadLine();
        }
    }
}