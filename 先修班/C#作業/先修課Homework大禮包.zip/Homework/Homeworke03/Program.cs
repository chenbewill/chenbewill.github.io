﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homeworke03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("請輸入整數:");
            string input = Console.ReadLine();
            int number = int.Parse(input);

            if (number % 2 == 0)
            {
                Console.WriteLine("是偶數");
            }
            else
            {
                Console.WriteLine("是奇數");
            }

            //string result = number % 2 == 0 ? "是偶數" : "是奇數";
            //Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}
