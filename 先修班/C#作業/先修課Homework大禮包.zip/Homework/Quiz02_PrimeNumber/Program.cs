﻿using System;

namespace Quiz02_PrimeNumber
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            for (int i = 1; i <= 200; i++)
            {
                //2
                if (IsPrime(i) == false) // !IsPrime(i)
                {
                    continue;
                }

                Console.WriteLine(i);
            }

            Console.ReadLine();
        }

        private static bool IsPrime(int number)
        {
            //大於2而且被2整除
            if(number > 2 && number % 2 == 0)
            {
                return false;
            }
            //number: 10
            int count = 0;
            for (int i = 1; i <= number; i++)
            {
                //number:10, i:10 => true
                if (number % i == 0)
                {
                    count++;
                    //count:4
                    if (count > 2)
                    {
                        break; //離開最近的迴圈
                    }
                }
            }

            //迴圈跑完時，count:2 true, 其他就是false

            if(count == 2)
            {
                return true;
            }
            else
            {
                return false;
            }
            
            //return count == 2;
        }

       
    }
}