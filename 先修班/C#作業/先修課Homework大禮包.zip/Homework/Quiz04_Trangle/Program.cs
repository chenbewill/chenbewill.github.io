﻿using System;
using System.Linq;

namespace Quiz04_Trangle
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("請輸入層數（1~9）：");
            string input = Console.ReadLine();
            int layer = int.Parse(input);

            for (int i = 0; i < layer; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(" ");
                }

                for (int k = layer; k > i; k--)
                {
                    
                    Console.Write(layer - i);
                }
                
                Console.WriteLine();
                
            }


            Console.WriteLine(string.Join(Environment.NewLine,
                Enumerable.Range(1, layer).Reverse().Select((item, index) =>
                    string.Concat(
                        string.Join(string.Empty, Enumerable.Repeat(" ", index)),
                        string.Join(string.Empty, Enumerable.Repeat(item, item))
                    )
                )));
            Console.ReadLine();
        }
    }
}