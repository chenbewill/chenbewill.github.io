﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //假設 1 美金 = 28 新台幣，請製作新台幣轉換為美元的程式。
            Console.WriteLine("請輸入新台幣:");
            double exchangRate = 28;
            string input = Console.ReadLine();
            double money = double.Parse(input);
            double dolar = money / exchangRate;

            Console.WriteLine("對應的美金為:");
            Console.WriteLine(dolar);

            Console.ReadLine();
        }
    }
}
