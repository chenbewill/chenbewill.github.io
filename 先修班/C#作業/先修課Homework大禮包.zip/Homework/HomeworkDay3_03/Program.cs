﻿using System;

namespace HomeworkDay3_03
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            //MyRectangle rect = new MyRectangle()
            //{
            //    Height = 10,
            //    Width = 10
            //};
            //ShowRectangle(rect);

            Console.WriteLine("請輸入圓形的半徑：");
            string input = Console.ReadLine();
            double radius = double.Parse(input);
            MyCircle circle1 = new MyCircle(radius);
            Console.WriteLine(circle1.Radius);
            ShowCircle(circle1);

            Console.WriteLine("----------");
            MyCircle circle2 = new MyCircle();
            ShowCircle(circle2);
            Console.ReadLine();
        }

        static void ShowRectangle(MyRectangle rectangle)
        {
            Console.WriteLine($"矩形的面積：{rectangle.GetArea()}，周長：{rectangle.GetPerimeter()}");
        }

        static void ShowCircle(MyCircle circle)
        {
            Console.WriteLine($"周長：{circle.GetPerimeter()}，面積：{circle.GetArea()}");
            Console.WriteLine($"周長：{circle.GetPerimeter().ToString("#.00")}，面積：{circle.GetArea().ToString("#.00")}");
        }
    }

    public class MyRectangle
    {
        public double Height { get; set; }
        public double Width { get; set; }

        public double GetPerimeter()
        {
            return 2 * (Height + Width);
        }

        public double GetArea()
        {
            return Width * Height;
        }
    }

    public class MyCircle
    {
        public MyCircle()
        {
            Console.WriteLine("請輸入圓形的半徑：");
            Radius = double.Parse(Console.ReadLine());
        }

        public MyCircle(double radius)
        {
            Radius = radius;
        }
        public double Radius { get; set; }

        public double GetPerimeter()
        {
            double pi = 3.14;
            return 2 * Radius * Math.PI;
        }

        public double GetArea()
        {
            double pi = 3.14;
            return Math.Pow(Radius, 2) * Math.PI;
        }
    }
    
}