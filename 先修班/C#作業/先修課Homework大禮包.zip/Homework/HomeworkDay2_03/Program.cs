﻿using System;

namespace HomeworkDay2_03
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int[] numArray = new int[10];
            // 320
            
            foreach (char item in input)
            {
                
                
                int value = Convert.ToInt32(item.ToString());
                
                numArray[value] = numArray[value] + 1;
            }
            
            for (int i = 0; i < numArray.Length; i++)
            {
                Console.WriteLine($"數字 {i} 出現 {numArray[i]} 次");
            }
            // 10 times
            // for (int i = 0; i < 10; i++)
            // {
            //     int count = input.Split(char.Parse(i.ToString())).Length - 1;
            //     Console.WriteLine($"數字 {i} 出現 {count} 次");
            // }
            
            Console.ReadLine();
        }
    }
}