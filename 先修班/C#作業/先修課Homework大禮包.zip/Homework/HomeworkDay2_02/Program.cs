﻿using System;

namespace HomeworkDay2_02
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            for (int i = 1; i <= 50; i++)
            {
                if (i % 3 == 0 || i % 5 == 0)
                {
                    continue;
                }

                Console.WriteLine(i);
            }

            for(int i = 1; i<=50; i++)
            {
                if(i % 3 != 0 && i % 5 != 0)
                {
                    Console.WriteLine(i);
                }
            }

            Console.ReadLine();
        }
    }
}