﻿using System;

namespace HomeworkDay3_01
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("請輸入一個有3位以上小數的數字：");
            string input = Console.ReadLine();
            double number = Double.Parse(input);
            Console.WriteLine($"{input} 無條件進位到整數位：{Math.Ceiling(number)}");
            Console.WriteLine($"{input} 無條件捨去到整數位：{Math.Floor(number)}");
            Console.WriteLine($"{input} 四捨五入到整小數第一位：{Math.Round(number, 1, MidpointRounding.AwayFromZero)}");

            Console.ReadLine();
        }
    }
}