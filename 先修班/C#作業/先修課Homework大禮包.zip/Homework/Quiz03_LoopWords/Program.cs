﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Quiz03_LoopWords
{
    internal class Program
    {
        public static void Main(string[] args)
        {

            string[] strArray = new string[] { "Hi", "My", "Name", "Is", "Andy" };
            string result = string.Join(Environment.NewLine, strArray);
            Console.WriteLine(result);

            string concatString = string.Concat("A","B","C");
            Console.WriteLine(concatString);

            //Console.Write("請輸入一段文字：");
            //string input = Console.ReadLine();


            //bool isLoopString = Judge(input);
            //bool isLoopString = JudgeV2(input);

            //Console.WriteLine(isLoopString ? "是回文" : "不是回文");

            Console.ReadLine();
        }

        static bool Judge(string source)
        {
            Console.WriteLine("V1..");
            ////把輸入的字串轉成char array
            //char[] sourceArr = source.ToCharArray();
            ////['1','2','3'] => ['3','2','1']
            //Array.Reverse(sourceArr);
            ////new string(char[]) 產生字串
            //string reverseString = new string(sourceArr);

            //return source == reverseString;


            string reverseSource = new String(source.Reverse().ToArray());
            return reverseSource == source;
        }

        static bool JudgeV2(string source)
        {
            Console.WriteLine("V2..");
            // 1 2 3 2 1 
            for (int i = 0; i < source.Length / 2; i++)
            {
                // '1' != '1'
                if (source[i] != source[source.Length - 1 - i])
                {
                    return false;
                }
            }

            return true;
        }

        static bool JudgeV3(string input)
        {
            char[] sourceArr = input.ToCharArray();
            char[] reverseArr = new char[sourceArr.Length];
            
            for (int i = 0; i < sourceArr.Length; i++)
            {
                reverseArr[i] = sourceArr[sourceArr.Length - 1 - i];
            }


            //123
            //321

            for(int i = 0; i < reverseArr.Length; i++)
            {
                // 1 != 3
                if(reverseArr[i] != sourceArr[i])
                {
                    return false;
                }
            }

            return true;
        }
    }

}