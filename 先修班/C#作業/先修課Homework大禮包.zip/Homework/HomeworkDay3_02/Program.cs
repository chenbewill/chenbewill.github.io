﻿using System;

namespace HomeworkDay3_02
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            int max = 100;
            int min = 1;
            int result = new Random().Next(min, max + 1);
            Console.WriteLine($"請輸入{min} - {max}之間整數");
            int guessNum = int.Parse(Console.ReadLine());
            
            //猜數字，猜對了才結束(離開迴圈)
            while (guessNum != result)
            {
                if (guessNum > result && guessNum < max)
                {
                    max = guessNum;
                }
                else if (guessNum < result && guessNum > min)
                {
                    min = guessNum;
                }
                
                Console.WriteLine($"請輸入{min} - {max}之間整數");
                guessNum = int.Parse(Console.ReadLine());

            }

            Console.WriteLine($"猜中了，答案是{result}");
            
            Console.ReadLine();
        }
    }
}